message = "Hi there!"
print(message)

message = "How are you today?"
print(message)
